a = "Aptech"
print(type(a))

b = """We are learning python in Aptech Learning. 
Aptech is situated near Nayapalli."""

print(b)