a = 5
print(type(a))
print(id(a))

b = 12.8787
print(type(b))
print(id(b))

c = 5+7j
print(type(c))
print(id(c))
