import random
print(random.randrange(1,10), random.randrange(1,10), random.randrange(1,10), random.randrange(1,10), random.randrange(1,10), random.randrange(1,10))

#9 7 4 5 6 6
#7 6 5 5 6 7