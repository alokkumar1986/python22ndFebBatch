a = 12
b = 3.14
c = 10-1j

'''
#x = a #implicit
x = float(a) #explicit
print(type(x))

y = b
print(type(y))

y = int(b)
print(type(y))

z = a 
print(type(z))

z = complex(a)
print(type(z))
'''

x = float(a)
y = int(b)

z = complex(a)
p = complex(b)

#q = int(c)
r = float(c)