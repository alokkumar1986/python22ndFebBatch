a = 'Aptech'
print(len(a))
print(a.upper())
print(a.lower())

print(a[0].lower()+a[1:6].upper())