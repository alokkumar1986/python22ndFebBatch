a = "Aptech"
print(a[:]) 
print(a[:4])
print(a[2:4])
print(a[1:4:2])
print(a[-5:-1])