potato = 20
str1 = f'1Kg potato costs {potato} Rs.'
print(str1)