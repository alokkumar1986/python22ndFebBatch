a = "Aptech"

print(a[0])
print(a[5])
#print(a[6])
print(a[-1])

print(a[-6])

print(a[0], a[1], a[2], a[3], a[4],a[5])
