a ='Aptech'
b = 'Learning'
c = a+' '+b
print(c)