name = input('Enter your name : ')
age = input('Enter your age : ')
str1 = f'My name is {name}. My age is {age}.'
print(str1)